def getCodes():
    global ckey, csecret, atoken, asecret
    ckey = 'WzES9cjvj6oNNcW3iFw8qGfSp'
    csecret = 'rCBAMzDQasS9pdEKeOzYzpMNmqUyQszt39xZWZdsTdhy4dqyYl'
    atoken = '845951541513216000-1sQ16foaD7uK3q580DzZMIF1JqAZajI'
    asecret = 'xcTh8KK89X9bUMUxQsv9NaWpuNxCnGQOuTrMTaZ9wiWYK'